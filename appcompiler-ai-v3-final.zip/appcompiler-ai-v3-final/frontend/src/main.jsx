import React, { useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import './styles.css';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000';

function App() {
  const [prompt, setPrompt] = useState('Build a CRM with login, contacts, dashboard, role-based access, premium plan with payments. Admins can see analytics.');
  const [config, setConfig] = useState(null);
  const [evaluation, setEvaluation] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const metrics = useMemo(() => {
    if (!config) return null;
    return {
      valid: config.validation_report?.valid,
      executable: config.execution_plan?.runtime_simulation?.executable,
      repairs: config.validation_report?.repair_count,
      retries: config.validation_report?.retries_per_request,
      latency: config.validation_report?.latency_ms,
      pages: config.ui?.pages?.length || 0,
      endpoints: config.api?.endpoints?.length || 0,
      tables: config.database?.tables?.length || 0,
    };
  }, [config]);

  async function generate() {
    setLoading(true);
    setError('');
    setEvaluation(null);
    try {
      const response = await fetch(`${API_URL}/generate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt }),
      });
      if (!response.ok) throw new Error(`Request failed: ${response.status}`);
      setConfig(await response.json());
    } catch (err) {
      setError(err.message || 'Something went wrong');
    } finally {
      setLoading(false);
    }
  }

  async function runEvaluation() {
    setLoading(true);
    setError('');
    try {
      const response = await fetch(`${API_URL}/evaluation/run`);
      if (!response.ok) throw new Error(`Evaluation failed: ${response.status}`);
      setEvaluation(await response.json());
    } catch (err) {
      setError(err.message || 'Evaluation failed');
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="shell">
      <section className="hero">
        <div>
          <p className="eyebrow">AI Engineer Demo Task</p>
          <h1>AppCompiler AI</h1>
          <p className="subtitle">Natural language → intent → architecture → strict config → validation + repair → runtime simulation.</p>
        </div>
        <div className="hero-card">
          <strong>Compiler principle</strong>
          <span>No single prompt. Every layer is generated, checked, repaired, and execution-simulated.</span>
        </div>
      </section>

      <section className="panel input-panel">
        <label htmlFor="prompt">Product prompt</label>
        <textarea id="prompt" value={prompt} onChange={(e) => setPrompt(e.target.value)} />
        <div className="actions">
          <button onClick={generate} disabled={loading}>{loading ? 'Working...' : 'Generate Config'}</button>
          <button className="secondary" onClick={runEvaluation} disabled={loading}>Run 20-Prompt Evaluation</button>
        </div>
        {error && <p className="error">{error}</p>}
      </section>

      {metrics && (
        <section className="grid metrics">
          <Metric label="Valid JSON + Schema" value={metrics.valid ? 'PASS' : 'FAIL'} />
          <Metric label="Executable" value={metrics.executable ? 'PASS' : 'FAIL'} />
          <Metric label="Repairs" value={metrics.repairs} />
          <Metric label="Retries" value={metrics.retries} />
          <Metric label="Latency" value={`${metrics.latency} ms`} />
          <Metric label="Pages / APIs / DB" value={`${metrics.pages} / ${metrics.endpoints} / ${metrics.tables}`} />
        </section>
      )}

      {config && (
        <section className="grid two">
          <div className="panel">
            <h2>Pipeline trace</h2>
            <div className="timeline">
              {config.pipeline_trace?.map((stage) => (
                <div className="stage" key={stage.stage}>
                  <span className={stage.status === 'failed' ? 'dot fail' : 'dot'}></span>
                  <div>
                    <strong>{stage.stage.replaceAll('_', ' ')}</strong>
                    <p>{stage.status} · {stage.latency_ms} ms</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="panel">
            <h2>Validation report</h2>
            {config.validation_report?.issues?.length ? (
              <ul className="issues">
                {config.validation_report.issues.map((issue, index) => (
                  <li key={index}><strong>{issue.code}</strong> · {issue.layer}: {issue.message}</li>
                ))}
              </ul>
            ) : <p>No blocking validation issues after targeted repair.</p>}
            {config.assumptions?.length > 0 && <>
              <h3>Assumptions</h3>
              <ul className="issues">{config.assumptions.map((a, i) => <li key={i}>{a}</li>)}</ul>
            </>}
          </div>
        </section>
      )}

      {evaluation && (
        <section className="panel">
          <h2>Evaluation metrics</h2>
          <div className="grid metrics">
            <Metric label="Total prompts" value={evaluation.total_prompts} />
            <Metric label="Success rate" value={`${Math.round(evaluation.success_rate * 100)}%`} />
            <Metric label="Avg latency" value={`${evaluation.avg_latency_ms} ms`} />
            <Metric label="Avg repairs" value={evaluation.avg_repair_count} />
          </div>
          <pre className="json">{JSON.stringify(evaluation, null, 2)}</pre>
        </section>
      )}

      {config && (
        <section className="panel">
          <h2>Generated strict JSON config</h2>
          <pre className="json">{JSON.stringify(config, null, 2)}</pre>
        </section>
      )}
    </main>
  );
}

function Metric({ label, value }) {
  return <div className="metric"><span>{label}</span><strong>{String(value)}</strong></div>;
}

createRoot(document.getElementById('root')).render(<App />);
