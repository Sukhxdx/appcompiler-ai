# Submission Guide

## What to submit

1. **Live URL**
   - Deploy the frontend.
   - Backend should be reachable by the frontend.
   - The evaluator should be able to enter a prompt and see generated JSON.

2. **GitHub repository**
   - Upload this whole folder.
   - Keep the README visible.
   - Make sure code is clean and structured.

3. **Loom video**
   - 5 to 10 minutes.
   - Explain architecture, pipeline, validation, repair, runtime simulation, and tradeoffs.

## Recommended GitHub description

```text
Compiler-style AI system that converts product prompts into strict validated executable app configs with multi-stage generation, cross-layer validation, targeted repair, runtime simulation, and evaluation metrics.
```

## Recommended Google Form summary

```text
I built AppCompiler AI, a compiler-style software generation system. It converts natural language product prompts into a strict application configuration across UI, API, database, auth, and business logic layers. The system is intentionally multi-stage: intent extraction, system design, schema generation, cross-layer validation, targeted repair, and runtime simulation. It includes Pydantic schema enforcement, targeted repair instead of blind retries, deterministic mock mode, a 20-prompt evaluation set, and metrics for success rate, retries, repair count, failure types, and latency.
```

## Deployment commands

### Backend on Render/Railway

Build command:

```bash
pip install -r backend/requirements.txt
```

Start command:

```bash
cd backend && uvicorn app.main:app --host 0.0.0.0 --port $PORT
```

### Frontend on Vercel

Root directory:

```text
frontend
```

Build command:

```bash
npm run build
```

Output directory:

```text
dist
```

Environment variable:

```text
VITE_API_URL=https://your-backend-url
```
