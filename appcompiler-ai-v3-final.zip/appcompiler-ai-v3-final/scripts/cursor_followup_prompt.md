# Cursor follow-up prompt for improving this project

Improve this AppCompiler AI repository without changing the core architecture.

Priorities:
1. Keep the multi-stage compiler pipeline separate.
2. Add tests for validator and repair engine.
3. Add a code emitter that writes generated React route files, FastAPI route stubs, and SQL migrations from AppConfig.
4. Keep `/generate`, `/evaluation/run`, and `/evaluation/results` working.
5. Do not replace the pipeline with a single LLM prompt.
6. Make the README stronger for internship submission.
