from __future__ import annotations

import re
from typing import Iterable

STOPWORDS = {
    "a", "an", "the", "with", "and", "or", "for", "to", "of", "in", "on", "by",
    "build", "create", "make", "app", "application", "system", "platform", "website",
    "that", "where", "can", "should", "must", "have", "has", "need", "needs",
    "where", "their", "them", "they", "all", "each", "using", "into", "from"
}


def slugify(value: str) -> str:
    value = value.lower().strip()
    value = re.sub(r"[^a-z0-9]+", "_", value)
    value = re.sub(r"_+", "_", value).strip("_")
    return value or "item"


def kebab(value: str) -> str:
    return slugify(value).replace("_", "-")


def singularize(value: str) -> str:
    value = slugify(value)
    if value.endswith("ies"):
        return value[:-3] + "y"
    if value.endswith("sses"):
        return value[:-2]
    if value.endswith("s") and not value.endswith("ss"):
        return value[:-1]
    return value


def pluralize(value: str) -> str:
    value = slugify(value)
    if value.endswith("y"):
        return value[:-1] + "ies"
    if value.endswith("s"):
        return value
    return value + "s"


def titleize(value: str) -> str:
    return slugify(value).replace("_", " ").title()


def unique_keep_order(values: Iterable[str]) -> list[str]:
    seen = set()
    output: list[str] = []
    for value in values:
        cleaned = slugify(value)
        if cleaned and cleaned not in seen:
            seen.add(cleaned)
            output.append(cleaned)
    return output


def infer_field_type(field: str) -> str:
    field = slugify(field)
    if field in {"id", "user_id", "owner_id", "created_by", "updated_by"} or field.endswith("_id"):
        return "uuid"
    if "email" in field:
        return "email"
    if "password" in field:
        return "password"
    if field.startswith("is_") or field in {"active", "verified", "paid", "premium"}:
        return "boolean"
    if "date" in field or "time" in field or field.endswith("_at"):
        return "datetime"
    if any(token in field for token in ["price", "amount", "total", "score", "rate"]):
        return "float"
    if any(token in field for token in ["count", "quantity", "number", "age"]):
        return "integer"
    if field in {"description", "body", "content", "notes"}:
        return "text"
    if field in {"status", "role", "plan", "priority", "type"}:
        return "enum"
    return "string"


def extract_candidate_nouns(prompt: str) -> list[str]:
    """Extract only business resources, not features or grammar fragments.

    This deterministic fallback deliberately avoids turning phrases like
    "role-based access" into a table called role_baseds or "admins can see
    analytics" into a table called sees. It is conservative because later
    stages can always add domain defaults such as CRM contacts/deals.
    """
    raw = re.split(r"[,.;]|\band\b|\bwith\b|\bplus\b|\bwhere\b|\bbut\b", prompt.lower())
    blocked = {
        "login", "signin", "sign_in", "signup", "dashboard", "admin", "admins",
        "premium", "payment", "payments", "analytics", "role", "roles", "based",
        "role_based", "access", "crud", "manage", "manages", "management",
        "user", "users", "see", "sees", "view", "views", "track", "tracks",
        "create", "creates", "crm", "customer", "customers", "plan", "plans",
        "subscription", "subscriptions", "auth", "authentication", "contact", "contacts"
    }
    candidates = []
    for part in raw:
        words = [slugify(w) for w in part.split()]
        words = [w for w in words if w and w not in STOPWORDS and len(w) > 2]
        phrase_words = [w for w in words if w not in blocked]
        if not phrase_words:
            continue
        # Keep a single compact resource noun. Multi-word phrases are often features.
        candidates.append(phrase_words[0])
    return unique_keep_order(candidates[:4])
