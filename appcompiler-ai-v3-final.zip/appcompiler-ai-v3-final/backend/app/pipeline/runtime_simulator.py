from __future__ import annotations

from app.schemas.app_config import AppConfig, RuntimeSimulation


class RuntimeSimulator:
    """Execution-awareness layer.

    This simulates whether a minimal React + FastAPI + SQLite runtime could be
    generated from the config without manual fixes.
    """

    def simulate(self, config: AppConfig) -> RuntimeSimulation:
        checks: list[dict] = []
        endpoints = {f"{endpoint.method} {endpoint.path}": endpoint for endpoint in config.api.endpoints}
        table_names = {table.name for table in config.database.tables}
        role_names = {role.name for role in config.auth.roles}

        def add_check(name: str, passed: bool, detail: str) -> None:
            checks.append({"name": name, "passed": passed, "detail": detail})

        add_check("json_contract", True, "Pydantic model serialized successfully to strict JSON.")
        add_check("database_migrations", bool(config.database.tables), f"{len(config.database.tables)} database migrations can be generated.")
        add_check("api_router", bool(config.api.endpoints), f"{len(config.api.endpoints)} FastAPI routes can be generated.")
        add_check("ui_routes", bool(config.ui.pages), f"{len(config.ui.pages)} React routes can be generated.")

        forms_ok = True
        for page in config.ui.pages:
            for component in page.components:
                if component.type in {"form", "button"} and component.endpoint:
                    forms_ok = forms_ok and component.endpoint in endpoints
                if component.entity:
                    forms_ok = forms_ok and component.entity in table_names
        add_check("ui_to_api_mapping", forms_ok, "All form/button components map to declared endpoints and entities." if forms_ok else "Some UI components cannot call a valid endpoint/entity.")

        api_db_ok = True
        for endpoint in config.api.endpoints:
            if endpoint.entity and endpoint.entity not in table_names:
                api_db_ok = False
        add_check("api_to_database_mapping", api_db_ok, "All entity-bound endpoints map to database tables." if api_db_ok else "Some endpoints reference missing tables.")

        auth_ok = True
        for page in config.ui.pages:
            for role in page.allowed_roles:
                if role != "guest" and role not in role_names:
                    auth_ok = False
        for endpoint in config.api.endpoints:
            for role in endpoint.required_roles:
                if role != "guest" and role not in role_names:
                    auth_ok = False
        add_check("auth_enforcement", auth_ok, "Every protected page and endpoint has enforceable role metadata." if auth_ok else "Some role references cannot be enforced.")

        validation_ok = config.validation_report.valid
        add_check("semantic_validation", validation_ok, "Cross-layer validator reports no blocking errors." if validation_ok else "Validation report contains blocking errors.")

        executable = all(check["passed"] for check in checks)
        simulated_files = [
            "generated/frontend/routes.tsx",
            "generated/backend/main.py",
            "generated/backend/models.py",
            "generated/backend/auth.py",
            "generated/db/migrations.sql",
        ]
        notes = [
            "Runtime is simulated intentionally for safe demo execution.",
            "The generated config is sufficient to generate CRUD pages, API routes, database migrations, and auth guards.",
        ]
        if not executable:
            notes.append("Simulation failed because at least one generated layer is inconsistent.")

        return RuntimeSimulation(executable=executable, checks=checks, simulated_files=simulated_files, notes=notes)
