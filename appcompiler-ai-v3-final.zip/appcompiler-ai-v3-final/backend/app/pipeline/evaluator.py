from __future__ import annotations

import json
import time
from collections import Counter
from pathlib import Path
from statistics import mean
from typing import Any

from app.pipeline.compiler import AppCompiler

DATA_DIR = Path(__file__).resolve().parents[1] / "data"
PROMPTS_FILE = DATA_DIR / "evaluation_prompts.json"
RESULTS_FILE = DATA_DIR / "evaluation_results.json"


class Evaluator:
    def __init__(self) -> None:
        self.compiler = AppCompiler()

    def run(self) -> dict[str, Any]:
        prompts = self._load_prompts()
        results = []
        failure_counter: Counter[str] = Counter()
        started = time.perf_counter()

        for item in prompts:
            prompt_start = time.perf_counter()
            config = self.compiler.compile(item["prompt"])
            success = config.validation_report.valid and config.execution_plan.runtime_simulation.executable
            for failure_type in config.validation_report.failure_types:
                failure_counter[failure_type] += 1
            if not success and not config.validation_report.failure_types:
                failure_counter["RUNTIME_SIMULATION_FAILED"] += 1
            repaired_notes = [note for note in config.assumptions if note.lower().startswith("repair ")]
            results.append({
                "id": item["id"],
                "category": item["category"],
                "prompt": item["prompt"],
                "success": success,
                "latency_ms": int((time.perf_counter() - prompt_start) * 1000),
                "repair_count": config.validation_report.repair_count,
                "retries_per_request": config.validation_report.retries_per_request,
                "failure_types": config.validation_report.failure_types,
                "clarification_needed": config.validation_report.clarification_needed,
                "executable": config.execution_plan.runtime_simulation.executable,
                "repaired_notes": repaired_notes,
                "output_summary": {
                    "pages": len(config.ui.pages),
                    "endpoints": len(config.api.endpoints),
                    "tables": len(config.database.tables),
                    "app_name": config.app_name,
                },
            })

        success_count = sum(1 for result in results if result["success"])
        repaired_examples = [
            {
                "id": r["id"],
                "prompt": r["prompt"],
                "repair_count": r["repair_count"],
                "repaired_notes": r["repaired_notes"],
                "output_summary": r["output_summary"],
            }
            for r in results
            if r["repair_count"] > 0
        ][:3]

        metrics = {
            "total_prompts": len(results),
            "success_count": success_count,
            "successful_prompts": success_count,
            "success_rate": round(success_count / len(results), 3) if results else 0,
            "avg_latency_ms": round(mean([r["latency_ms"] for r in results]), 2) if results else 0,
            "average_latency_ms": round(mean([r["latency_ms"] for r in results]), 2) if results else 0,
            "total_repairs": sum(r["repair_count"] for r in results),
            "avg_repair_count": round(mean([r["repair_count"] for r in results]), 2) if results else 0,
            "average_repairs_per_prompt": round(mean([r["repair_count"] for r in results]), 2) if results else 0,
            "avg_retries_per_request": round(mean([r["retries_per_request"] for r in results]), 2) if results else 0,
            "failure_types": dict(failure_counter),
            "repaired_examples": repaired_examples,
            "total_evaluation_latency_ms": int((time.perf_counter() - started) * 1000),
            "cost_quality_tradeoff": {
                "default_mode": "mock_deterministic",
                "quality_strategy": "Use deterministic stages first, validate each layer, and repair only invalid layers.",
                "latency_strategy": "Avoid full retries; run one validation and up to three targeted repair passes.",
                "cost_strategy": "In LLM mode, use cheaper model for intent/design and stronger model only when repair cannot resolve semantic failures.",
            },
            "results": results,
        }
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        RESULTS_FILE.write_text(json.dumps(metrics, indent=2), encoding="utf-8")
        return metrics

    def read_results(self) -> dict[str, Any]:
        if not RESULTS_FILE.exists():
            return {"message": "No evaluation results yet. Call /evaluation/run first."}
        return json.loads(RESULTS_FILE.read_text(encoding="utf-8"))

    @staticmethod
    def _load_prompts() -> list[dict[str, Any]]:
        if not PROMPTS_FILE.exists():
            raise FileNotFoundError(f"Missing evaluation prompts at {PROMPTS_FILE}")
        return json.loads(PROMPTS_FILE.read_text(encoding="utf-8"))
