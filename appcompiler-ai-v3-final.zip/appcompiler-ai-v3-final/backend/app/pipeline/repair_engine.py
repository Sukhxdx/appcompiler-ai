from __future__ import annotations

from copy import deepcopy
from app.schemas.app_config import (
    APIEndpoint,
    AppConfig,
    DBField,
    DBTable,
    Permission,
    Role,
    ValidationIssue,
)
from app.pipeline.utils import infer_field_type, kebab, pluralize, titleize
from app.pipeline.validator import CrossLayerValidator


class RepairEngine:
    """Targeted repairs for known schema/cross-layer failures.

    Important: this does not blindly regenerate the whole config. It mutates only
    the layer that caused a semantic mismatch, then re-validates.
    """

    def __init__(self, max_passes: int = 3) -> None:
        self.max_passes = max_passes
        self.validator = CrossLayerValidator()

    def repair(self, config: AppConfig) -> AppConfig:
        repaired = deepcopy(config)
        report = self.validator.validate(repaired)
        repair_count = repaired.validation_report.repair_count
        retries = 0

        for _ in range(self.max_passes):
            error_issues = [issue for issue in report.issues if issue.severity == "error" and issue.repairable]
            if not error_issues:
                break
            retries += 1
            before = repaired.model_dump_json()
            for issue in error_issues:
                if self._apply_issue_repair(repaired, issue):
                    repair_count += 1
            after = repaired.model_dump_json()
            if before == after:
                break
            report = self.validator.validate(repaired)

        final_report = self.validator.validate(repaired)
        final_report.repair_count = repair_count
        final_report.retries_per_request = retries
        final_report.clarification_needed = repaired.validation_report.clarification_needed
        repaired.validation_report = final_report
        return repaired

    def _apply_issue_repair(self, config: AppConfig, issue: ValidationIssue) -> bool:
        message = issue.message
        if issue.code in {"API_ENTITY_MISSING", "UI_ENTITY_MISSING", "BUSINESS_ENTITY_MISSING"}:
            entity = self._quoted_tail(message)
            if entity:
                return self._ensure_table(config, entity)
        if issue.code in {"API_FIELD_MISSING", "UI_FIELD_MISSING"}:
            field = self._extract_between(message, "field '", "'")
            table = self._extract_between(message, "table '", "'")
            if field and table:
                return self._ensure_field(config, table, field)
        if issue.code in {"API_ROLE_MISSING", "PAGE_ROLE_MISSING", "COMPONENT_ROLE_MISSING", "BUSINESS_ROLE_MISSING"}:
            role = self._quoted_tail(message)
            if role:
                return self._ensure_role(config, role)
        if issue.code in {"UI_ENDPOINT_MISSING", "BUSINESS_ENDPOINT_MISSING", "PERMISSION_ENDPOINT_MISSING"}:
            endpoint_ref = self._quoted_tail(message)
            if endpoint_ref:
                return self._ensure_endpoint(config, endpoint_ref)
        if issue.code == "DB_ID_MISSING":
            table = self._quoted_tail(message)
            if table:
                return self._ensure_field(config, table, "id")
        if issue.code == "PERMISSION_PAGE_MISSING":
            route = self._quoted_tail(message)
            if route:
                config.assumptions.append(f"Repair added placeholder page for missing permission route {route}.")
                # A complete placeholder page is not needed here for standard generation; keep simple.
                return False
        return False

    def _ensure_table(self, config: AppConfig, entity: str) -> bool:
        entity = pluralize(entity)
        if any(table.name == entity for table in config.database.tables):
            return False
        config.database.tables.append(DBTable(
            name=entity,
            description=f"Auto-repaired table for {titleize(entity)} referenced by another layer.",
            fields=[
                DBField(name="id", type="uuid", required=True, unique=True),
                DBField(name="name", type="string", required=True),
                DBField(name="description", type="text", required=False),
                DBField(name="status", type="enum", required=True, enum_values=["active", "inactive", "archived"]),
                DBField(name="created_at", type="datetime", required=True),
            ],
            relations=[],
        ))
        config.assumptions.append(f"Repair added missing database table '{entity}'.")
        return True

    def _ensure_field(self, config: AppConfig, table_name: str, field_name: str) -> bool:
        table_name = pluralize(table_name)
        table = next((table for table in config.database.tables if table.name == table_name), None)
        if table is None:
            self._ensure_table(config, table_name)
            table = next((table for table in config.database.tables if table.name == table_name), None)
        if table is None or any(field.name == field_name for field in table.fields):
            return False
        field_type = infer_field_type(field_name)
        table.fields.append(DBField(name=field_name, type=field_type, required=field_name == "id"))  # type: ignore[arg-type]
        config.assumptions.append(f"Repair added missing field '{field_name}' to table '{table_name}'.")
        return True

    def _ensure_role(self, config: AppConfig, role_name: str) -> bool:
        if role_name == "guest" or any(role.name == role_name for role in config.auth.roles):
            return False
        config.auth.roles.append(Role(name=role_name, description=f"Auto-repaired {titleize(role_name)} role", permissions=[]))
        config.assumptions.append(f"Repair added missing auth role '{role_name}'.")
        return True

    def _ensure_endpoint(self, config: AppConfig, endpoint_ref: str) -> bool:
        if any(f"{endpoint.method} {endpoint.path}" == endpoint_ref for endpoint in config.api.endpoints):
            return False
        parts = endpoint_ref.split(" ", 1)
        if len(parts) != 2:
            return False
        method, path = parts
        entity = path.strip("/").split("/")[0] or None
        if entity in {"auth", "analytics"}:
            entity = None
        elif entity:
            entity = pluralize(entity)
            self._ensure_table(config, entity)
        config.api.endpoints.append(APIEndpoint(
            path=path,
            method=method,  # type: ignore[arg-type]
            description=f"Auto-repaired endpoint for {endpoint_ref}.",
            entity=entity,
            action="auto_repaired",
            request_fields=[] if method == "GET" else ["id"],
            response_fields=["id", "status"] if entity else ["status"],
            required_roles=[role.name for role in config.auth.roles if role.name != "guest"] or ["user"],
        ))
        config.assumptions.append(f"Repair added missing endpoint '{endpoint_ref}'.")
        return True

    @staticmethod
    def _extract_between(value: str, start: str, end: str) -> str | None:
        try:
            return value.split(start, 1)[1].split(end, 1)[0]
        except IndexError:
            return None

    @staticmethod
    def _quoted_tail(value: str) -> str | None:
        if "'" not in value:
            return None
        try:
            return value.rsplit("'", 2)[1]
        except IndexError:
            return None
