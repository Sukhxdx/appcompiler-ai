from __future__ import annotations

import re
from app.schemas.intent import Intent
from app.pipeline.utils import slugify, titleize, unique_keep_order, extract_candidate_nouns


DOMAIN_ENTITY_MAP = {
    "crm": ["contacts", "companies", "deals", "activities"],
    "customer relationship": ["contacts", "companies", "deals", "activities"],
    "ecommerce": ["products", "customers", "orders", "payments"],
    "shop": ["products", "customers", "orders", "payments"],
    "marketplace": ["products", "vendors", "orders", "payments"],
    "task": ["tasks", "projects", "comments"],
    "project management": ["projects", "tasks", "comments", "teams"],
    "blog": ["posts", "comments", "categories"],
    "content": ["posts", "media", "categories"],
    "learning": ["courses", "lessons", "enrollments"],
    "lms": ["courses", "lessons", "enrollments"],
    "booking": ["bookings", "customers", "resources", "payments"],
    "inventory": ["products", "stock_movements", "suppliers"],
    "hr": ["employees", "departments", "leave_requests"],
    "finance": ["transactions", "accounts", "invoices"],
    "invoice": ["invoices", "customers", "payments"],
    "restaurant": ["menu_items", "orders", "tables", "reservations"],
    "health": ["patients", "appointments", "records"],
}

FEATURE_KEYWORDS = {
    "login": ["auth", "login"],
    "signup": ["auth", "signup"],
    "register": ["auth", "signup"],
    "dashboard": ["dashboard"],
    "analytics": ["analytics"],
    "payment": ["payments"],
    "payments": ["payments"],
    "premium": ["premium_gating"],
    "subscription": ["subscription"],
    "role": ["role_based_access"],
    "admin": ["admin_panel"],
    "upload": ["file_upload"],
    "notification": ["notifications"],
    "search": ["search"],
    "chat": ["chat"],
    "calendar": ["calendar"],
}


def _infer_app_name(prompt: str, entities: list[str]) -> str:
    lower = prompt.lower().strip()
    match = re.search(r"(?:build|create|make)\s+(?:an?\s+)?([a-zA-Z0-9\- ]{2,45}?)(?:\s+with|\s+for|\s+that|[,.;]|$)", lower)
    if match:
        candidate = match.group(1)
        candidate = re.sub(r"\b(app|application|platform|system|website)\b", "", candidate).strip()
        if candidate:
            return titleize(candidate)
    if entities:
        return f"{titleize(entities[0])} Manager"
    return "Generated App"


def extract_intent(prompt: str) -> Intent:
    lower = prompt.lower().strip()
    features: list[str] = []
    roles = ["user"]
    entities: list[str] = []
    app_type = "custom_app"
    ambiguities: list[str] = []
    conflicts: list[str] = []
    assumptions: list[str] = []

    for domain, mapped_entities in DOMAIN_ENTITY_MAP.items():
        if domain in lower:
            app_type = slugify(domain)
            entities.extend(mapped_entities)

    for keyword, mapped_features in FEATURE_KEYWORDS.items():
        if keyword in lower:
            features.extend(mapped_features)

    if "admin" in lower or "owner" in lower:
        roles.append("admin")
    if "manager" in lower:
        roles.append("manager")
    if "premium" in lower or "subscription" in lower or "paid" in lower:
        roles.append("premium_user")
    if "guest" in lower or "public" in lower:
        roles.append("guest")

    # Explicit entity-ish terms from common nouns in the prompt.
    entities.extend(extract_candidate_nouns(prompt))

    if any(word in lower for word in ["login", "signup", "auth", "user", "admin", "role"]):
        entities.append("users")
        features.append("auth")

    if "payment" in lower or "premium" in lower or "subscription" in lower:
        entities.extend(["plans", "payments"])
        features.extend(["payments", "premium_gating"])

    if "assign" in lower and "task" in lower:
        entities.append("tasks")
        entities.append("users")
        features.append("task_assignment")
        assumptions.append("Task assignment enabled: tasks include assignee_id referencing users.id.")

    if "analytics" in lower or "dashboard" in lower:
        features.append("dashboard")

    if len(lower.split()) < 5 or lower in {"make app", "build app", "create dashboard"}:
        ambiguities.append("Prompt is too vague to infer complete product scope.")
        assumptions.append("Defaulting to a secure CRUD dashboard with users, dashboard, and one primary resource.")
        entities.append("items")
        features.extend(["auth", "dashboard", "crud"])

    if "no login" in lower and any(term in lower for term in ["admin", "role", "premium"]):
        conflicts.append("Prompt asks for no login but also includes role-gated/admin/premium behavior.")
        assumptions.append("Auth is enabled because role-gated behavior cannot be enforced without identity.")
        features.append("auth")
        entities.append("users")

    if "free" in lower and "premium" in lower and "only" in lower:
        conflicts.append("Prompt mentions free-only and premium behavior together; premium gating is treated as optional upgrade.")
        assumptions.append("Free users can access core pages; premium users receive advanced features.")

    entities = unique_keep_order(entities)
    roles = unique_keep_order(roles)
    features = unique_keep_order(features or ["crud", "dashboard"])
    flows = ["authentication"] if "auth" in features else []
    if any(f in features for f in ["payments", "premium_gating", "subscription"]):
        flows.append("subscription_checkout")
    if "dashboard" in features:
        flows.append("dashboard_navigation")
    flows.append("resource_management")

    confidence = 0.85
    if ambiguities:
        confidence -= 0.25
    if conflicts:
        confidence -= 0.15
    confidence = max(0.35, min(confidence, 0.95))

    return Intent(
        raw_prompt=prompt,
        app_name=_infer_app_name(prompt, entities),
        app_type=app_type,
        entities=entities,
        roles=roles,
        features=features,
        flows=unique_keep_order(flows),
        constraints=[],
        ambiguities=ambiguities,
        conflicts=conflicts,
        assumptions=assumptions,
        confidence=confidence,
    )
