from __future__ import annotations

from app.schemas.design import SystemDesign
from app.schemas.app_config import (
    APIEndpoint,
    APISchema,
    AppConfig,
    AuthConfig,
    BusinessRule,
    DatabaseSchema,
    DBField,
    DBRelation,
    DBTable,
    ExecutionPlan,
    Permission,
    Role,
    UIComponent,
    UIPage,
    UISchema,
)
from app.pipeline.utils import infer_field_type, kebab, pluralize, slugify, titleize, unique_keep_order

SYSTEM_TABLES = {"users", "payments", "plans"}
CRUD_EXCLUDED = {"users", "payments", "plans"}


def _db_field(name: str) -> DBField:
    normalized = slugify(name)
    field_type = infer_field_type(normalized)
    enum_values: list[str] = []
    if normalized == "status":
        enum_values = ["active", "inactive", "archived"]
    elif normalized == "role":
        enum_values = ["user", "admin", "premium_user"]
    elif normalized == "plan":
        enum_values = ["free", "premium"]
    elif normalized == "priority":
        enum_values = ["low", "medium", "high"]
    return DBField(
        name=normalized,
        type=field_type,  # type: ignore[arg-type]
        required=normalized in {"id", "name", "email", "title", "status"},
        unique=normalized in {"id", "email"},
        enum_values=enum_values,
    )


def _table_for_entity(entity_name: str, fields: list[str]) -> DBTable:
    normalized = pluralize(entity_name)
    db_fields = [_db_field(field) for field in unique_keep_order(fields)]
    field_names = {f.name for f in db_fields}
    if "id" not in field_names:
        db_fields.insert(0, _db_field("id"))
    if "created_at" not in field_names:
        db_fields.append(_db_field("created_at"))

    relations: list[DBRelation] = []
    for field in db_fields:
        if field.name.endswith("_id") and field.name != "id":
            target_base = field.name[:-3]
            target = "users" if target_base in {"owner", "author", "user", "assignee"} else pluralize(target_base)
            relations.append(DBRelation(from_table=normalized, from_field=field.name, to_table=target, to_field="id"))
    return DBTable(name=normalized, description=f"Persistent store for {titleize(normalized)}.", fields=db_fields, relations=relations)


def _field_names(table: DBTable) -> list[str]:
    return [field.name for field in table.fields]


def _display_fields(table: DBTable) -> list[str]:
    fields = _field_names(table)
    preferred = ["id", "name", "title", "email", "status", "priority", "assignee_id", "amount", "created_at"]
    selected = [f for f in preferred if f in fields]
    if len(selected) < 4:
        selected.extend([f for f in fields if f not in selected and f not in {"password_hash", "owner_id", "user_id", "company_id", "contact_id"}])
    return selected[:5]


def _write_fields(table: DBTable) -> list[str]:
    fields = _field_names(table)
    excluded = {"id", "created_at", "updated_at", "password_hash", "owner_id", "user_id"}
    preferred = ["name", "title", "assignee_id", "email", "phone", "description", "status", "priority", "amount", "domain", "notes", "type"]
    selected = [f for f in preferred if f in fields and f not in excluded]
    if not selected:
        selected = [f for f in fields if f not in excluded][:3]
    return selected[:5]


def _crud_endpoints(table: DBTable, roles: list[str]) -> list[APIEndpoint]:
    entity = table.name
    path = f"/{kebab(entity)}"
    allowed_roles = [role for role in roles if role != "guest"] or ["user"]
    admin_roles = ["admin"] if "admin" in roles else allowed_roles
    response_fields = _display_fields(table)
    request_fields = _write_fields(table)
    required_key = next((f for f in ["name", "title", "email"] if f in request_fields), request_fields[0] if request_fields else "id")
    return [
        APIEndpoint(path=path, method="GET", description=f"List {entity}.", entity=entity, action="list", response_fields=response_fields, required_roles=allowed_roles),
        APIEndpoint(path=path, method="POST", description=f"Create {entity}.", entity=entity, action="create", request_fields=request_fields, response_fields=response_fields, required_roles=allowed_roles, validation={required_key: "required"}),
        APIEndpoint(path=f"{path}/{{id}}", method="GET", description=f"Read one {entity} record.", entity=entity, action="read", request_fields=["id"], response_fields=response_fields, required_roles=allowed_roles),
        APIEndpoint(path=f"{path}/{{id}}", method="PATCH", description=f"Update {entity}.", entity=entity, action="update", request_fields=["id", *request_fields], response_fields=response_fields, required_roles=allowed_roles),
        APIEndpoint(path=f"{path}/{{id}}", method="DELETE", description=f"Delete {entity}.", entity=entity, action="delete", request_fields=["id"], response_fields=[f for f in ["id", "status"] if f in _field_names(table)] or ["id"], required_roles=admin_roles),
    ]


def _admin_user_endpoints(roles: list[str]) -> list[APIEndpoint]:
    if "admin" not in roles:
        return []
    return [
        APIEndpoint(path="/users", method="GET", description="Admin list users.", entity="users", action="list_users", response_fields=["id", "name", "email", "role", "plan", "created_at"], required_roles=["admin"]),
        APIEndpoint(path="/users/{id}", method="PATCH", description="Admin update a user role or plan.", entity="users", action="update_user", request_fields=["id", "role", "plan"], response_fields=["id", "name", "email", "role", "plan"], required_roles=["admin"]),
        APIEndpoint(path="/users/{id}", method="DELETE", description="Admin deactivate or delete a user.", entity="users", action="delete_user", request_fields=["id"], response_fields=["id", "role"], required_roles=["admin"]),
    ]


def _roles(roles: list[str], pages: list[UIPage], endpoints: list[APIEndpoint]) -> list[Role]:
    role_objects: list[Role] = []
    for role in roles:
        resources: list[Permission] = []
        page_routes = [p.route for p in pages if role in p.allowed_roles]
        endpoint_routes = [f"{e.method} {e.path}" for e in endpoints if role in e.required_roles]
        resources.extend([Permission(resource=f"page:{route}", actions=["read"]) for route in page_routes])
        resources.extend([Permission(resource=f"endpoint:{route}", actions=["execute"]) for route in endpoint_routes])
        role_objects.append(Role(name=role, description=f"{titleize(role)} role", permissions=resources))
    return role_objects


def generate_schema(design: SystemDesign) -> AppConfig:
    roles = unique_keep_order(design.roles or ["user"])
    if "user" not in roles:
        roles.insert(0, "user")

    tables = [_table_for_entity(entity.name, entity.fields) for entity in design.entities]
    table_map = {table.name: table for table in tables}
    if "users" not in table_map:
        user_table = _table_for_entity("users", ["id", "name", "email", "password_hash", "role", "plan", "created_at"])
        tables.insert(0, user_table)
        table_map["users"] = user_table

    table_names = {table.name for table in tables}
    endpoints: list[APIEndpoint] = [
        APIEndpoint(
            path="/auth/login",
            method="POST",
            description="Authenticate using email and password.",
            entity="users",
            action="login",
            request_fields=["email", "password_hash"],
            response_fields=["id", "name", "email", "role", "plan"],
            required_roles=unique_keep_order(["guest", *roles]),
        ),
        APIEndpoint(
            path="/auth/me",
            method="GET",
            description="Return current session user.",
            entity="users",
            action="current_user",
            response_fields=["id", "name", "email", "role", "plan"],
            required_roles=[role for role in roles if role != "guest"] or ["user"],
        ),
    ]

    crud_tables = [table for table in tables if table.name not in CRUD_EXCLUDED]
    for table in crud_tables:
        endpoints.extend(_crud_endpoints(table, roles))
    endpoints.extend(_admin_user_endpoints(roles))

    if "admin" in roles:
        endpoints.append(APIEndpoint(path="/analytics/summary", method="GET", description="Aggregate KPI metrics for admins.", entity=None, action="analytics_summary", response_fields=["total_users", "total_records", "premium_users"], required_roles=["admin"]))

    if "plans" in table_names:
        endpoints.append(APIEndpoint(path="/plans", method="GET", description="List available billing plans.", entity="plans", action="list_plans", response_fields=["id", "name", "price", "features", "is_active"], required_roles=[role for role in roles if role != "guest"] or ["user"]))
    if "payments" in table_names or "premium_user" in roles:
        endpoints.append(APIEndpoint(path="/payments/checkout", method="POST", description="Create premium plan checkout session.", entity="payments", action="checkout", request_fields=["user_id", "amount", "provider"], response_fields=["id", "status", "amount"], required_roles=[role for role in roles if role != "guest"] or ["user"], validation={"amount": "positive"}))

    auth_roles = [role for role in roles if role != "guest"] or ["user"]
    pages: list[UIPage] = [
        UIPage(
            name="Login",
            route="/login",
            layout="auth",
            allowed_roles=unique_keep_order(["guest", *auth_roles]),
            components=[UIComponent(id="login_form", type="form", label="Login", entity="users", fields=["email", "password_hash"], endpoint="POST /auth/login", visible_to=unique_keep_order(["guest", *auth_roles]))],
        ),
        UIPage(
            name="Dashboard",
            route="/dashboard",
            layout="dashboard",
            allowed_roles=auth_roles,
            components=[
                UIComponent(id="welcome_card", type="card", label="Overview", visible_to=auth_roles, props={"text": "Summary of application activity"}),
                UIComponent(id="activity_metric", type="metric", label="Total Records", fields=["total_records"], endpoint="GET /analytics/summary" if "admin" in roles else None, visible_to=["admin"] if "admin" in roles else auth_roles),
                UIComponent(id="premium_metric", type="metric", label="Premium Users", fields=["premium_users"], endpoint="GET /analytics/summary" if "admin" in roles else None, visible_to=["admin"] if "admin" in roles else auth_roles),
            ],
        ),
    ]

    for table in crud_tables[:6]:
        pages.append(UIPage(
            name=f"{titleize(table.name)} Management",
            route=f"/{kebab(table.name)}",
            layout="crud",
            allowed_roles=auth_roles,
            components=[
                UIComponent(id=f"{slugify(table.name)}_table", type="table", label=f"{titleize(table.name)} Table", entity=table.name, fields=_display_fields(table), endpoint=f"GET /{kebab(table.name)}", visible_to=auth_roles),
                UIComponent(id=f"{slugify(table.name)}_form", type="form", label=f"Create {titleize(table.name)}", entity=table.name, fields=_write_fields(table), endpoint=f"POST /{kebab(table.name)}", visible_to=auth_roles),
            ],
        ))

    if "admin" in roles:
        pages.append(UIPage(
            name="Admin Users",
            route="/admin/users",
            layout="crud",
            allowed_roles=["admin"],
            components=[
                UIComponent(id="admin_users_table", type="table", label="Users Table", entity="users", fields=["id", "name", "email", "role", "plan"], endpoint="GET /users", visible_to=["admin"]),
                UIComponent(id="admin_user_role_form", type="form", label="Update User Access", entity="users", fields=["role", "plan"], endpoint="PATCH /users/{id}", visible_to=["admin"]),
            ],
        ))
        pages.append(UIPage(
            name="Admin Analytics",
            route="/admin/analytics",
            layout="dashboard",
            allowed_roles=["admin"],
            components=[
                UIComponent(id="admin_kpis", type="chart", label="Admin KPIs", fields=["total_users", "total_records", "premium_users"], endpoint="GET /analytics/summary", visible_to=["admin"], props={"chart_type": "bar"}),
            ],
        ))

    if "payments" in table_names or "plans" in table_names or "premium_user" in roles:
        pages.append(UIPage(
            name="Billing",
            route="/billing",
            layout="settings",
            allowed_roles=auth_roles,
            components=[
                UIComponent(id="plan_cards", type="card", label="Plans", entity="plans", fields=["id", "name", "price", "features"], endpoint="GET /plans" if "plans" in table_names else None, visible_to=auth_roles),
                UIComponent(id="checkout_button", type="button", label="Upgrade to Premium", entity="payments", fields=["user_id", "amount", "provider"], endpoint="POST /payments/checkout", visible_to=auth_roles),
            ],
        ))

    business_logic: list[BusinessRule] = []
    for idx, rule in enumerate(design.business_rules, start=1):
        lower_rule = rule.lower()
        referenced_roles = [role for role in roles if role in lower_rule]
        referenced_entities = [table.name for table in tables if table.name.rstrip("s") in lower_rule or table.name in lower_rule]
        referenced_endpoints: list[str] = []
        if "analytics" in lower_rule:
            referenced_endpoints.append("GET /analytics/summary")
        if "premium" in lower_rule or "payment" in lower_rule:
            referenced_endpoints.append("POST /payments/checkout")
        if "assignee" in lower_rule or "task" in lower_rule:
            if "tasks" in table_names:
                referenced_entities = unique_keep_order([*referenced_entities, "tasks", "users"])
            referenced_endpoints.extend([route for route in ["POST /tasks", "PATCH /tasks/{id}"] if any(f"{e.method} {e.path}" == route for e in endpoints)])
        business_logic.append(BusinessRule(id=f"BR-{idx:03}", description=rule, condition=rule, action="enforce_access_or_state_transition", referenced_roles=referenced_roles, referenced_entities=referenced_entities, referenced_endpoints=referenced_endpoints))

    ui = UISchema(pages=pages)
    api = APISchema(endpoints=endpoints)
    database = DatabaseSchema(tables=tables)
    auth = AuthConfig(login_required=True, roles=_roles(roles, pages, endpoints))
    execution_plan = ExecutionPlan(
        pages_to_render=[page.route for page in pages],
        api_routes=[f"{endpoint.method} {endpoint.path}" for endpoint in endpoints],
        db_migrations=[f"CREATE TABLE {table.name} (...{len(table.fields)} fields...)" for table in tables],
    )

    return AppConfig(
        app_name=design.app_name,
        description=f"Compiler-generated configuration for {design.app_name}.",
        assumptions=design.assumptions,
        ui=ui,
        api=api,
        database=database,
        auth=auth,
        business_logic=business_logic,
        execution_plan=execution_plan,
    )
