from __future__ import annotations

from app.schemas.intent import Intent
from app.schemas.design import EntityDesign, FlowDesign, SystemDesign
from app.pipeline.utils import singularize, pluralize, titleize, unique_keep_order


DEFAULT_FIELDS = {
    "users": ["id", "name", "email", "password_hash", "role", "plan", "created_at"],
    "contacts": ["id", "name", "email", "phone", "company_id", "owner_id", "created_at"],
    "companies": ["id", "name", "domain", "owner_id", "created_at"],
    "deals": ["id", "title", "amount", "status", "contact_id", "owner_id", "created_at"],
    "activities": ["id", "type", "notes", "contact_id", "owner_id", "created_at"],
    "products": ["id", "name", "description", "price", "status", "created_at"],
    "orders": ["id", "customer_id", "status", "total_amount", "created_at"],
    "customers": ["id", "name", "email", "phone", "created_at"],
    "payments": ["id", "user_id", "amount", "status", "provider", "created_at"],
    "plans": ["id", "name", "price", "features", "is_active", "created_at"],
    "tasks": ["id", "title", "description", "status", "priority", "owner_id", "created_at"],
    "projects": ["id", "name", "description", "status", "owner_id", "created_at"],
    "comments": ["id", "body", "user_id", "created_at"],
    "posts": ["id", "title", "content", "status", "author_id", "created_at"],
    "categories": ["id", "name", "created_at"],
    "courses": ["id", "title", "description", "status", "created_at"],
    "lessons": ["id", "course_id", "title", "content", "created_at"],
    "enrollments": ["id", "user_id", "course_id", "status", "created_at"],
    "items": ["id", "name", "description", "status", "created_at"],
}


def fields_for_entity(entity: str) -> list[str]:
    entity = pluralize(entity)
    if entity in DEFAULT_FIELDS:
        return DEFAULT_FIELDS[entity]
    singular = singularize(entity)
    return ["id", "name" if singular not in {"transaction", "invoice"} else "title", "description", "status", "owner_id", "created_at"]


def build_system_design(intent: Intent) -> SystemDesign:
    entity_names = unique_keep_order([pluralize(e) for e in intent.entities])
    if "users" not in entity_names and "auth" in intent.features:
        entity_names.insert(0, "users")
    if "task_assignment" in intent.features and "users" not in entity_names:
        entity_names.insert(0, "users")

    entities = []
    for entity in entity_names:
        fields = fields_for_entity(entity)
        relationships = [] if entity == "users" else (["owner_id -> users.id"] if "users" in entity_names else [])
        if entity == "tasks" and "task_assignment" in intent.features:
            fields = list(fields)
            if "assignee_id" not in fields:
                insert_at = fields.index("created_at") if "created_at" in fields else len(fields)
                fields.insert(insert_at, "assignee_id")
            if "assignee_id -> users.id" not in relationships:
                relationships.append("assignee_id -> users.id")
        entities.append(EntityDesign(
            name=entity,
            description=f"Stores {titleize(entity)} records used by the application.",
            fields=fields,
            relationships=relationships,
        ))

    pages = ["Login", "Dashboard"] if "auth" in intent.features else ["Dashboard"]
    crud_entities = [e for e in entity_names if e not in {"users", "payments", "plans"}]
    pages.extend([f"{titleize(entity)} Management" for entity in crud_entities[:6]])

    if "admin" in intent.roles:
        pages.append("Admin Analytics")
    if any(f in intent.features for f in ["payments", "premium_gating", "subscription"]):
        pages.append("Billing")

    flows = []
    if "auth" in intent.features:
        flows.append(FlowDesign(name="Login", actor="user", steps=["Submit email/password", "Validate credentials", "Return session and role", "Route to dashboard"]))
    flows.append(FlowDesign(name="Manage Resources", actor="user", steps=["Open management page", "View table", "Create or edit record", "Persist through API", "Refresh UI state"]))
    if "admin" in intent.roles:
        flows.append(FlowDesign(name="View Analytics", actor="admin", steps=["Open admin analytics", "Fetch aggregate metrics", "Render charts and KPI cards"]))
    if any(f in intent.features for f in ["payments", "premium_gating", "subscription"]):
        flows.append(FlowDesign(name="Upgrade Plan", actor="user", steps=["Open billing", "Select premium plan", "Create checkout session", "Record payment", "Unlock premium role"]))

    business_rules = []
    if "admin" in intent.roles:
        business_rules.append("Only admins can access analytics and administrative metrics.")
    if "premium_user" in intent.roles:
        business_rules.append("Premium-only components require premium_user or admin role.")
    if "auth" in intent.features:
        business_rules.append("All protected API endpoints require authenticated users.")
    if "task_assignment" in intent.features:
        business_rules.append("Task assignee must reference an existing user.")

    assumptions = list(intent.assumptions)
    if intent.ambiguities:
        assumptions.append("Ambiguous requirements are resolved using conservative defaults and clarification questions are exposed in the output.")
    if not crud_entities:
        assumptions.append("No separate business entity was specified; user/admin management is treated as the primary resource.")

    clarification_questions = []
    if intent.ambiguities:
        clarification_questions.append("What is the primary resource users should manage?")
    if intent.conflicts:
        clarification_questions.append("Should authentication be enabled to enforce role-based behavior?")

    return SystemDesign(
        app_name=intent.app_name,
        app_type=intent.app_type,
        entities=entities,
        roles=unique_keep_order(intent.roles),
        pages=unique_keep_order(pages),
        flows=flows,
        api_groups=unique_keep_order([e.name for e in entities] + (["analytics"] if "admin" in intent.roles else []) + (["payments"] if "payments" in intent.features else [])),
        business_rules=business_rules,
        assumptions=assumptions,
        clarification_needed=bool(intent.ambiguities or intent.conflicts),
        clarification_questions=clarification_questions,
    )
