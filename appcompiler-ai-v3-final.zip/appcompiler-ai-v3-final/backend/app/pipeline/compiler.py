from __future__ import annotations

import time
from typing import Any

from app.pipeline.intent_extractor import extract_intent
from app.pipeline.system_designer import build_system_design
from app.pipeline.schema_generator import generate_schema
from app.pipeline.repair_engine import RepairEngine
from app.pipeline.runtime_simulator import RuntimeSimulator
from app.pipeline.validator import CrossLayerValidator
from app.schemas.app_config import AppConfig


class AppCompiler:
    def __init__(self) -> None:
        self.validator = CrossLayerValidator()
        self.repair_engine = RepairEngine(max_passes=3)
        self.runtime = RuntimeSimulator()

    def compile(self, prompt: str) -> AppConfig:
        start = time.perf_counter()
        trace: list[dict[str, Any]] = []

        stage_start = time.perf_counter()
        intent = extract_intent(prompt)
        trace.append({
            "stage": "intent_extraction",
            "status": "completed",
            "latency_ms": self._elapsed(stage_start),
            "summary": intent.model_dump(),
        })

        stage_start = time.perf_counter()
        design = build_system_design(intent)
        trace.append({
            "stage": "system_design",
            "status": "completed",
            "latency_ms": self._elapsed(stage_start),
            "summary": design.model_dump(),
        })

        stage_start = time.perf_counter()
        config = generate_schema(design)
        config.validation_report.clarification_needed = design.clarification_needed
        trace.append({
            "stage": "schema_generation",
            "status": "completed",
            "latency_ms": self._elapsed(stage_start),
            "summary": {
                "pages": len(config.ui.pages),
                "endpoints": len(config.api.endpoints),
                "tables": len(config.database.tables),
                "roles": len(config.auth.roles),
            },
        })

        stage_start = time.perf_counter()
        report = self.validator.validate(config)
        report.clarification_needed = design.clarification_needed
        config.validation_report = report
        trace.append({
            "stage": "cross_layer_validation",
            "status": "completed",
            "latency_ms": self._elapsed(stage_start),
            "summary": {"valid": report.valid, "issues": [issue.model_dump() for issue in report.issues]},
        })

        stage_start = time.perf_counter()
        config = self.repair_engine.repair(config)
        trace.append({
            "stage": "targeted_repair",
            "status": "completed",
            "latency_ms": self._elapsed(stage_start),
            "summary": {
                "valid_after_repair": config.validation_report.valid,
                "repair_count": config.validation_report.repair_count,
                "retries_per_request": config.validation_report.retries_per_request,
                "remaining_issues": [issue.model_dump() for issue in config.validation_report.issues],
            },
        })

        stage_start = time.perf_counter()
        simulation = self.runtime.simulate(config)
        config.execution_plan.runtime_simulation = simulation
        trace.append({
            "stage": "runtime_simulation",
            "status": "completed" if simulation.executable else "failed",
            "latency_ms": self._elapsed(stage_start),
            "summary": simulation.model_dump(),
        })

        config.pipeline_trace = trace
        config.validation_report.latency_ms = self._elapsed(start)
        return config

    @staticmethod
    def _elapsed(stage_start: float) -> int:
        return max(1, int((time.perf_counter() - stage_start) * 1000))
