from __future__ import annotations

from app.schemas.app_config import AppConfig, ValidationIssue, ValidationReport

SYSTEM_ENDPOINT_PREFIXES = ("/auth", "/analytics")


class CrossLayerValidator:
    """Validates the generated config like a compiler semantic-analysis pass."""

    def validate(self, config: AppConfig) -> ValidationReport:
        issues: list[ValidationIssue] = []
        table_names = {table.name for table in config.database.tables}
        table_fields = {table.name: {field.name for field in table.fields} for table in config.database.tables}
        role_names = {role.name for role in config.auth.roles}
        endpoints = {f"{endpoint.method} {endpoint.path}": endpoint for endpoint in config.api.endpoints}
        page_routes = {page.route for page in config.ui.pages}

        if not config.app_name.strip():
            issues.append(self._issue("error", "REQUIRED_APP_NAME", "root", "app_name is required."))
        if not config.ui.pages:
            issues.append(self._issue("error", "NO_PAGES", "ui", "At least one UI page is required."))
        if not config.api.endpoints:
            issues.append(self._issue("error", "NO_ENDPOINTS", "api", "At least one API endpoint is required."))
        if not config.database.tables:
            issues.append(self._issue("error", "NO_TABLES", "database", "At least one database table is required."))

        for endpoint in config.api.endpoints:
            if endpoint.entity and endpoint.entity not in table_names:
                issues.append(self._issue("error", "API_ENTITY_MISSING", "api", f"Endpoint {endpoint.method} {endpoint.path} references unknown DB table '{endpoint.entity}'."))
            if endpoint.entity in table_fields:
                allowed = table_fields[endpoint.entity]
                for field in endpoint.request_fields + endpoint.response_fields:
                    if field not in allowed and field not in {"password", "token", "total_users", "total_records", "premium_users"}:
                        issues.append(self._issue("error", "API_FIELD_MISSING", "api", f"Endpoint {endpoint.method} {endpoint.path} references field '{field}' that does not exist on table '{endpoint.entity}'."))
            for role in endpoint.required_roles:
                if role not in role_names and role != "guest":
                    issues.append(self._issue("error", "API_ROLE_MISSING", "api", f"Endpoint {endpoint.method} {endpoint.path} uses unknown role '{role}'."))

        for page in config.ui.pages:
            if not page.route.startswith("/"):
                issues.append(self._issue("error", "INVALID_ROUTE", "ui", f"Page '{page.name}' route must start with '/'."))
            for role in page.allowed_roles:
                if role not in role_names and role != "guest":
                    issues.append(self._issue("error", "PAGE_ROLE_MISSING", "ui", f"Page {page.route} uses unknown role '{role}'."))
            for component in page.components:
                if component.entity and component.entity not in table_names:
                    issues.append(self._issue("error", "UI_ENTITY_MISSING", "ui", f"Component {component.id} references unknown table '{component.entity}'."))
                if component.entity in table_fields:
                    for field in component.fields:
                        if field not in table_fields[component.entity]:
                            issues.append(self._issue("error", "UI_FIELD_MISSING", "ui", f"Component {component.id} references unknown field '{field}' on table '{component.entity}'."))
                if component.endpoint and component.endpoint not in endpoints:
                    issues.append(self._issue("error", "UI_ENDPOINT_MISSING", "ui", f"Component {component.id} references missing endpoint '{component.endpoint}'."))
                for role in component.visible_to:
                    if role not in role_names and role != "guest":
                        issues.append(self._issue("error", "COMPONENT_ROLE_MISSING", "ui", f"Component {component.id} uses unknown role '{role}'."))

        for role in config.auth.roles:
            for permission in role.permissions:
                if permission.resource.startswith("page:"):
                    route = permission.resource.split("page:", 1)[1]
                    if route not in page_routes:
                        issues.append(self._issue("error", "PERMISSION_PAGE_MISSING", "auth", f"Role {role.name} references missing page route '{route}'."))
                elif permission.resource.startswith("endpoint:"):
                    endpoint_ref = permission.resource.split("endpoint:", 1)[1]
                    if endpoint_ref not in endpoints:
                        issues.append(self._issue("error", "PERMISSION_ENDPOINT_MISSING", "auth", f"Role {role.name} references missing endpoint '{endpoint_ref}'."))

        for rule in config.business_logic:
            for role in rule.referenced_roles:
                if role not in role_names:
                    issues.append(self._issue("error", "BUSINESS_ROLE_MISSING", "business_logic", f"Business rule {rule.id} references missing role '{role}'."))
            for entity in rule.referenced_entities:
                if entity not in table_names:
                    issues.append(self._issue("error", "BUSINESS_ENTITY_MISSING", "business_logic", f"Business rule {rule.id} references missing entity '{entity}'."))
            for endpoint in rule.referenced_endpoints:
                if endpoint not in endpoints:
                    issues.append(self._issue("error", "BUSINESS_ENDPOINT_MISSING", "business_logic", f"Business rule {rule.id} references missing endpoint '{endpoint}'."))

        for table in config.database.tables:
            field_names = {field.name for field in table.fields}
            if "id" not in field_names:
                issues.append(self._issue("error", "DB_ID_MISSING", "database", f"Table '{table.name}' is missing id field."))
            for relation in table.relations:
                if relation.to_table not in table_names:
                    issues.append(self._issue("warning", "RELATION_TARGET_MISSING", "database", f"Relation {table.name}.{relation.from_field} references missing table '{relation.to_table}'."))
                if relation.from_field not in field_names:
                    issues.append(self._issue("error", "RELATION_FIELD_MISSING", "database", f"Relation on table '{table.name}' uses missing field '{relation.from_field}'."))

        failure_types = sorted({issue.code for issue in issues if issue.severity == "error"})
        return ValidationReport(
            valid=not any(issue.severity == "error" for issue in issues),
            issues=issues,
            failure_types=failure_types,
            clarification_needed=config.validation_report.clarification_needed,
            repair_count=config.validation_report.repair_count,
            retries_per_request=config.validation_report.retries_per_request,
            latency_ms=config.validation_report.latency_ms,
        )

    @staticmethod
    def _issue(severity: str, code: str, layer: str, message: str, repairable: bool = True) -> ValidationIssue:
        return ValidationIssue(severity=severity, code=code, layer=layer, message=message, repairable=repairable)
