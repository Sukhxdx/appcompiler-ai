from __future__ import annotations

import os
from typing import Any


class LLMProvider:
    """Provider abstraction for future LLM integration.

    The demo works without an API key because the compiler pipeline has a
    deterministic mock/heuristic implementation. This provider is intentionally
    isolated so the pipeline contract does not depend on a specific model vendor.
    """

    def __init__(self) -> None:
        self.mode = os.getenv("MODEL_MODE", "mock")
        self.model = os.getenv("MODEL_NAME", "gpt-4o-mini")

    def generate_json(self, system_prompt: str, user_prompt: str, schema_hint: dict[str, Any]) -> dict[str, Any]:
        if self.mode == "mock":
            return {"mode": "mock", "message": "Deterministic local pipeline used."}
        raise NotImplementedError(
            "LLM mode is intentionally stubbed for the demo. Add OpenAI/Gemini SDK call here, keep temperature=0, and validate against Pydantic models."
        )
