from __future__ import annotations


class MockProvider:
    def generate(self, prompt: str) -> dict:
        return {"provider": "mock", "prompt_length": len(prompt)}
