from __future__ import annotations

from typing import Any
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from app.pipeline.compiler import AppCompiler
from app.pipeline.evaluator import Evaluator


class GenerateRequest(BaseModel):
    prompt: str = Field(min_length=2, examples=["Build a CRM with login, contacts, dashboard, role-based access, premium plan with payments. Admins can see analytics."])


app = FastAPI(
    title="AppCompiler AI",
    description="Natural language to validated executable app configuration.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

compiler = AppCompiler()
evaluator = Evaluator()


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/generate")
def generate(request: GenerateRequest) -> dict[str, Any]:
    config = compiler.compile(request.prompt)
    return config.model_dump(mode="json")


@app.get("/evaluation/run")
def run_evaluation() -> dict[str, Any]:
    return evaluator.run()


@app.get("/evaluation/results")
def evaluation_results() -> dict[str, Any]:
    return evaluator.read_results()
