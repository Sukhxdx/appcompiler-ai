from __future__ import annotations

from pydantic import BaseModel, Field


class EntityDesign(BaseModel):
    name: str
    description: str
    fields: list[str] = Field(default_factory=list)
    relationships: list[str] = Field(default_factory=list)


class FlowDesign(BaseModel):
    name: str
    actor: str
    steps: list[str] = Field(default_factory=list)


class SystemDesign(BaseModel):
    app_name: str
    app_type: str
    entities: list[EntityDesign]
    roles: list[str]
    pages: list[str]
    flows: list[FlowDesign]
    api_groups: list[str]
    business_rules: list[str]
    assumptions: list[str] = Field(default_factory=list)
    clarification_needed: bool = False
    clarification_questions: list[str] = Field(default_factory=list)
