from __future__ import annotations

from typing import Any, Literal
from pydantic import BaseModel, Field

FieldType = Literal["string", "text", "integer", "float", "boolean", "datetime", "email", "password", "enum", "uuid"]
HttpMethod = Literal["GET", "POST", "PUT", "PATCH", "DELETE"]
Severity = Literal["error", "warning", "info"]


class DBField(BaseModel):
    name: str
    type: FieldType = "string"
    required: bool = False
    unique: bool = False
    default: Any | None = None
    enum_values: list[str] = Field(default_factory=list)


class DBRelation(BaseModel):
    from_table: str
    from_field: str
    to_table: str
    to_field: str = "id"
    relation_type: Literal["one_to_one", "one_to_many", "many_to_one", "many_to_many"] = "many_to_one"


class DBTable(BaseModel):
    name: str
    description: str = ""
    fields: list[DBField] = Field(default_factory=list)
    relations: list[DBRelation] = Field(default_factory=list)


class DatabaseSchema(BaseModel):
    tables: list[DBTable] = Field(default_factory=list)


class APIEndpoint(BaseModel):
    path: str
    method: HttpMethod
    description: str
    entity: str | None = None
    action: str
    request_fields: list[str] = Field(default_factory=list)
    response_fields: list[str] = Field(default_factory=list)
    required_roles: list[str] = Field(default_factory=list)
    validation: dict[str, Any] = Field(default_factory=dict)


class APISchema(BaseModel):
    endpoints: list[APIEndpoint] = Field(default_factory=list)


class UIComponent(BaseModel):
    id: str
    type: Literal["form", "table", "chart", "card", "button", "nav", "text", "metric"]
    label: str
    entity: str | None = None
    fields: list[str] = Field(default_factory=list)
    endpoint: str | None = None
    visible_to: list[str] = Field(default_factory=list)
    props: dict[str, Any] = Field(default_factory=dict)


class UIPage(BaseModel):
    name: str
    route: str
    layout: Literal["auth", "dashboard", "crud", "landing", "settings"] = "dashboard"
    allowed_roles: list[str] = Field(default_factory=list)
    components: list[UIComponent] = Field(default_factory=list)


class UISchema(BaseModel):
    pages: list[UIPage] = Field(default_factory=list)


class Permission(BaseModel):
    resource: str
    actions: list[str] = Field(default_factory=list)


class Role(BaseModel):
    name: str
    description: str = ""
    permissions: list[Permission] = Field(default_factory=list)


class AuthConfig(BaseModel):
    login_required: bool = True
    providers: list[str] = Field(default_factory=lambda: ["email_password"])
    roles: list[Role] = Field(default_factory=list)


class BusinessRule(BaseModel):
    id: str
    description: str
    condition: str
    action: str
    referenced_roles: list[str] = Field(default_factory=list)
    referenced_entities: list[str] = Field(default_factory=list)
    referenced_endpoints: list[str] = Field(default_factory=list)


class RuntimeSimulation(BaseModel):
    executable: bool = False
    checks: list[dict[str, Any]] = Field(default_factory=list)
    simulated_files: list[str] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)


class ExecutionPlan(BaseModel):
    runtime: str = "simulated_react_fastapi_sqlite"
    pages_to_render: list[str] = Field(default_factory=list)
    api_routes: list[str] = Field(default_factory=list)
    db_migrations: list[str] = Field(default_factory=list)
    runtime_simulation: RuntimeSimulation = Field(default_factory=RuntimeSimulation)


class ValidationIssue(BaseModel):
    severity: Severity
    code: str
    layer: str
    message: str
    repairable: bool = True


class ValidationReport(BaseModel):
    valid: bool = False
    issues: list[ValidationIssue] = Field(default_factory=list)
    repair_count: int = 0
    retries_per_request: int = 0
    failure_types: list[str] = Field(default_factory=list)
    clarification_needed: bool = False
    latency_ms: int = 0


class AppConfig(BaseModel):
    app_name: str
    description: str
    assumptions: list[str] = Field(default_factory=list)
    ui: UISchema
    api: APISchema
    database: DatabaseSchema
    auth: AuthConfig
    business_logic: list[BusinessRule] = Field(default_factory=list)
    execution_plan: ExecutionPlan
    validation_report: ValidationReport = Field(default_factory=ValidationReport)
    pipeline_trace: list[dict[str, Any]] = Field(default_factory=list)
