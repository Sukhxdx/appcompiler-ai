from __future__ import annotations

from typing import Literal
from pydantic import BaseModel, Field


class Intent(BaseModel):
    raw_prompt: str
    app_name: str
    app_type: str = "custom_app"
    entities: list[str] = Field(default_factory=list)
    roles: list[str] = Field(default_factory=list)
    features: list[str] = Field(default_factory=list)
    flows: list[str] = Field(default_factory=list)
    constraints: list[str] = Field(default_factory=list)
    ambiguities: list[str] = Field(default_factory=list)
    conflicts: list[str] = Field(default_factory=list)
    assumptions: list[str] = Field(default_factory=list)
    confidence: float = Field(ge=0.0, le=1.0, default=0.75)


class PipelineStage(BaseModel):
    name: str
    status: Literal["pending", "running", "completed", "failed"] = "pending"
    latency_ms: int = 0
    details: dict = Field(default_factory=dict)
