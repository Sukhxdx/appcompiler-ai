# AppCompiler AI

**AI Engineer Internship Demo Task**  
Natural language product requirements are compiled into a strict, validated, executable application configuration.

The goal is not to show a single clever prompt. The goal is to show a controlled compiler-style system:

```text
Natural language
  -> Intent Extraction
  -> System Design Layer
  -> Schema Generation
  -> Cross-layer Validation
  -> Targeted Repair Engine
  -> Runtime Simulation
  -> Evaluation Metrics
```

## Why this fits the assignment

The demo task asks for a system that behaves like a compiler for software generation: natural language to structured config, validated, executable, and able to produce a working application through a runtime or simulation.

This project implements:

1. **Multi-stage generation pipeline**
   - `intent_extractor.py`
   - `system_designer.py`
   - `schema_generator.py`
   - `validator.py`
   - `repair_engine.py`
   - `runtime_simulator.py`

2. **Strict schema enforcement**
   - Pydantic v2 models define the contract for UI, API, DB, auth, business logic, execution plan, and validation report.
   - `/generate` always returns JSON generated from typed Pydantic models.

3. **Validation + repair engine**
   - Detects missing keys, unknown entities, missing DB fields, missing endpoints, missing roles, invalid UI/API/DB mappings, and permission inconsistencies.
   - Repairs specific broken layers only. It does not blindly retry the full generation.

4. **Deterministic behavior**
   - Default mode is deterministic and mock/local, so the same input gives stable output.
   - The LLM provider is isolated so model calls can be added without weakening validation.

5. **Execution awareness**
   - The runtime simulator checks whether pages, forms, endpoints, DB tables, auth roles, and business rules are coherent enough to generate a minimal React + FastAPI + SQLite app.

6. **Failure handling**
   - Vague, incomplete, and conflicting prompts are handled through assumptions, clarification flags, and conservative defaults.

7. **Evaluation framework**
   - `evaluation_prompts.json` contains 20 prompts: 10 normal product prompts and 10 edge cases.
   - Tracks success rate, retries per request, failure types, repair count, and latency.

8. **Cost vs quality tradeoff**
   - Uses deterministic stages first.
   - Avoids full LLM retries.
   - Repairs only invalid layers.
   - Keeps stronger model calls optional for cases that cannot be repaired locally.

## Folder structure

```text
appcompiler-ai/
  backend/
    app/
      main.py
      schemas/
        app_config.py
        intent.py
        design.py
      pipeline/
        compiler.py
        intent_extractor.py
        system_designer.py
        schema_generator.py
        validator.py
        repair_engine.py
        runtime_simulator.py
        evaluator.py
      data/
        evaluation_prompts.json
      llm/
        provider.py
        mock_provider.py
    requirements.txt
  frontend/
    src/
      main.jsx
      styles.css
    package.json
  SUBMISSION_GUIDE.md
  LOOM_SCRIPT.md
```

## Run locally

### 1. Start backend

```bash
cd backend
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

Open backend docs:

```text
http://localhost:8000/docs
```

### 2. Start frontend

Open a second terminal:

```bash
cd frontend
npm install
npm run dev
```

Open:

```text
http://localhost:5173
```

## API usage

### Generate config

```bash
curl -X POST http://localhost:8000/generate \
  -H "Content-Type: application/json" \
  -d '{"prompt":"Build a CRM with login, contacts, dashboard, role-based access, and premium plan with payments. Admins can see analytics."}'
```

### Run evaluation

```bash
curl http://localhost:8000/evaluation/run
```

### Read last evaluation results

```bash
curl http://localhost:8000/evaluation/results
```

## Design decisions

### Why multiple stages?

A single LLM prompt is hard to control. This system separates the problem into compiler-like phases:

- Intent extraction decides what the user wants.
- System design decides architecture.
- Schema generation creates strict UI/API/DB/auth/business config.
- Validation checks semantic consistency.
- Repair fixes only the broken part.
- Runtime simulation proves the output can power an app generator.

### Why Pydantic?

Pydantic gives runtime type safety and guarantees valid JSON serialization. It also makes schema contracts explicit and easy to inspect.

### Why targeted repair?

Full retries are expensive and unstable. Targeted repair is more reliable because it uses the exact validation issue to update only the invalid layer.

Example:

```text
UI references POST /contacts but API does not define it
-> repair only API schema by adding POST /contacts
-> re-run validation
```

### How deterministic behavior is handled

- Default mode uses deterministic heuristics.
- No random sampling.
- Same prompt creates stable entities, roles, pages, APIs, tables, and validation logic.
- LLM mode can be added later with `temperature=0`, schema-constrained outputs, and model responses validated through Pydantic.

### Runtime simulation

The runtime simulator validates whether a minimal generator could create:

- React routes
- CRUD pages
- FastAPI endpoints
- SQLite migrations
- auth guards
- role-gated pages

It marks `executable=true` only when all simulation checks pass.

## What to show in the Loom video

Use `LOOM_SCRIPT.md`. Keep the video between 5 and 10 minutes.

## Deployment suggestion

- Backend: Render, Railway, or Fly.io
- Frontend: Vercel or Netlify
- Set frontend env var:

```text
VITE_API_URL=https://your-backend-url
```

## Current limitation

This is a demo runtime simulator, not a complete app generator. It proves execution awareness by checking whether the generated configuration is internally consistent and sufficient to generate a working app. A production version would add a code emitter that turns this config into actual React/FastAPI/SQL files.

## Reviewer-focused checks in v1.1

This version includes additional semantic guards to avoid common LLM/config-generation failures:

- feature phrases such as `role-based access` are not converted into fake database tables;
- action words such as `see analytics` are not converted into entities;
- dashboard metric cards avoid sensitive login fields such as passwords;
- admin user-management pages and endpoints are added when admin/user-management behavior is inferred;
- CRUD endpoints use fields that actually exist on each database table, so entities such as `deals` can use `title` instead of a fake `name` field;
- evaluation output includes repaired examples, total repairs, average repairs per prompt, latency, success rate, and failure types.
