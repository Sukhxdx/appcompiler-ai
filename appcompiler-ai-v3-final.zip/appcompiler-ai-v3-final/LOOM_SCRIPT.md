# Loom Video Script: AppCompiler AI

## 0:00 - 0:45 Introduction

Hi, this is my demo task submission: AppCompiler AI. The goal is to convert natural language app requirements into a strict, validated, executable application configuration. I treated the task as a compiler and reliability problem, not as a single prompt engineering problem.

## 0:45 - 2:00 Architecture overview

The pipeline has six major stages:

1. Intent extraction
2. System design
3. Schema generation
4. Cross-layer validation
5. Targeted repair
6. Runtime simulation

The backend is FastAPI. The strict contracts are Pydantic models. The frontend is React and gives a simple interface to enter a prompt, see pipeline stages, validation errors, assumptions, runtime checks, metrics, and final JSON.

## 2:00 - 3:00 Multi-stage pipeline

Intent extraction identifies app type, entities, roles, features, flows, assumptions, and conflicts. The system design stage converts that into architecture: entities, flows, pages, API groups, roles, and business rules. Schema generation then creates UI config, API config, database schema, auth rules, business logic, and execution plan.

This separation is important because each layer can be validated and repaired independently.

## 3:00 - 4:30 Validation and repair

The validator checks cross-layer consistency. For example:

- API fields must exist in the database table.
- UI forms must map to real API endpoints.
- Components must reference valid entities and fields.
- Role permissions must reference existing pages and endpoints.
- Business rules must reference existing roles, entities, and endpoints.

The repair engine is targeted. It does not blindly retry the entire generation. If the UI references a missing endpoint, it repairs the API layer. If an API references a missing DB field, it adds that field to the correct table and documents the assumption.

## 4:30 - 5:30 Runtime simulation

The runtime simulator checks if a minimal React + FastAPI + SQLite app could be generated from the config. It validates pages, API routes, DB migrations, UI-to-API mappings, API-to-DB mappings, and auth enforcement. The output is marked executable only when these checks pass.

## 5:30 - 6:30 Evaluation framework

I included 20 prompts: 10 normal product prompts and 10 edge cases. The system tracks success rate, latency, repair count, retries per request, failure types, clarification flags, and runtime executability. This gives actual metrics instead of only claims.

## 6:30 - 7:30 Cost vs quality tradeoff

The default system is deterministic and local, which makes it cheap and stable. In a production LLM setup, I would use a cheaper model for intent and design, then reserve stronger model calls for unresolved repair cases. The key tradeoff is: validate and repair locally first, use model calls only when necessary.

## 7:30 - 8:30 Demo

Now I will enter a CRM prompt. The system generates the config, shows the pipeline trace, validation report, assumptions, runtime checks, and final JSON. Then I will run the 20-prompt evaluation and show the success metrics.

## 8:30 - 9:00 Closing

This project is intentionally designed as an engineered system: modular, validated, repairable, deterministic, and execution-aware. The current runtime is simulated, and the next step would be adding a code emitter to generate actual React, FastAPI, and SQL files from the validated config.
